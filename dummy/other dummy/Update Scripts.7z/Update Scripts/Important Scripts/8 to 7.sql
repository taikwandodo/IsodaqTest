USE [XView14c]
GO

UPDATE [Manage].[UserAccounts]
SET  [Manage].[UserAccounts].Tabs = 8
WHERE [Manage].[UserAccounts].Tabs = 7


