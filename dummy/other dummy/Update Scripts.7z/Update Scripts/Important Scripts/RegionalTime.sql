ALTER TABLE Manage.UserAccounts 
ADD [UseRegionalTime] bit NOT NULL 
CONSTRAINT DefualtAlter DEFAULT 0
