USE [XVIEW14CTest_Unused]
GO

/****** Object:  Table [Interface].[ExternalInterfaces]    Script Date: 29/09/2015 12:30:59 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Interface].[ExternalInterfaces](
	[ExternalInterfaceId] [int] IDENTITY(1,1) NOT NULL,
	[ExternalInterfaceType] [varchar](100) NOT NULL,
	[DataFormat] [varchar](50) NOT NULL CONSTRAINT [DF_ExternaInterfaces_DataFormat]  DEFAULT ('API'),
	[Keys] [int] NOT NULL CONSTRAINT [DF_ExternaInterfaces_Keys]  DEFAULT ((0)),
	[KeyName1] [varchar](50) NULL,
	[KeyName2] [varchar](50) NULL,
	[KeyName3] [varchar](50) NULL,
	[KeyName4] [varchar](50) NULL,
	[DefaultFilenameMask] [varchar](50) NULL,
	[SubFolderName] [varchar](50) NULL,
 CONSTRAINT [PK_ExternaInterfaces] PRIMARY KEY CLUSTERED 
(
	[ExternalInterfaceId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY],
 CONSTRAINT [IX_ExternalInterfaces_1] UNIQUE NONCLUSTERED 
(
	[ExternalInterfaceType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


