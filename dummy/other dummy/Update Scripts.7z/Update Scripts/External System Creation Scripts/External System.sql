USE [XVIEW14CTest_Unused]
GO

/****** Object:  Table [Interface].[ExternalLinking]    Script Date: 29/09/2015 12:28:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [Interface].[ExternalLinking](
	[ExternalLinkingId] [int] IDENTITY(1,1) NOT NULL,
	[ExternalSystemId] [int] NOT NULL,
	[TVDBiStationName] [varchar](255) NOT NULL,
	[TVDBiChannelNumber] [int] NOT NULL,
	[TVDBiParameterName] [varchar](25) NULL,
	[TVDBiMeasurementUnit] [varchar](20) NULL,
	[TVDBiGroupName] [varchar](255) NOT NULL,
	[OverrideIPAddress] [varchar](100) NULL,
	[Key1] [varchar](255) NULL,
	[Key2] [varchar](255) NULL,
	[Key3] [varchar](255) NULL,
	[Key4] [varchar](255) NULL,
	[RecordsPerDay] [int] NOT NULL,
	[ActiveLink] [bit] NOT NULL,
	[LastRequestedDateTime] [datetime] NOT NULL,
	[LastRecordDateTime] [datetime] NULL,
 CONSTRAINT [PK_ExternalLinkingTable] PRIMARY KEY CLUSTERED 
(
	[ExternalLinkingId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [Interface].[ExternalLinking]  WITH CHECK ADD  CONSTRAINT [FK_ExternalLinkingTable_ExternalSystems] FOREIGN KEY([ExternalSystemId])
REFERENCES [Interface].[ExternalSystems] ([ExternalSystemId])
GO

ALTER TABLE [Interface].[ExternalLinking] CHECK CONSTRAINT [FK_ExternalLinkingTable_ExternalSystems]
GO


