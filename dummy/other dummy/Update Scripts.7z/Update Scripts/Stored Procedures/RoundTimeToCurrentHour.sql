USE [XVIEW14CTest]
GO

/****** Object:  UserDefinedFunction [dbo].[RoundTimeToCurrentHour]    Script Date: 29/09/2015 12:24:56 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[RoundTimeToCurrentHour]
(
	@time DATETIME
)
RETURNS DATETIME
AS
BEGIN

	IF(DATEPART(MINUTE, @time) > 30)
	BEGIN
	
		/* Decrease time by one hour so that the roundup at the end will effectively round down */
		SET @time = DATEADD(HOUR, -1, @time)
		
	END

	/* Return the rounded time value */
	RETURN CAST(ROUND(CAST(CAST(CONVERT(VARCHAR, @time, 13) AS DATETIME) AS FLOAT) * 24, 0) / 24 AS SMALLDATETIME)

END

GO

