USE [XVIEW14CTest]
GO

/****** Object:  UserDefinedFunction [dbo].[RoundTimeTo]    Script Date: 29/09/2015 12:23:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[RoundTimeTo]
(
	@time datetime,
	@interval float /* fractional part of an hour - 0.25 equates to 15 minutes (quarter of an hour) */
)
RETURNS datetime
AS
BEGIN

	/* @interval can be a whole number as well, not just a fraction, e.g. 12 will round to midnight or midday */

	/* Return the rounded time value */
    RETURN CAST( ROUND(CAST(CAST(CONVERT(VARCHAR, @time, 13) AS DATETIME) AS FLOAT) * (24/@interval), 0) / (24/@interval) AS SMALLDATETIME )

END









GO


